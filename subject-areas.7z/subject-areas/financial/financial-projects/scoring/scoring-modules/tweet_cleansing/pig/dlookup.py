#!/opt/Python-2.7.6/python
import pickle
from nltk.util import ngrams
import re, pickle
import os
import sys
import string
import time

try:
      rumour_keywords = ['Buzz', 'Heard on the street', 'tie up', 'curbs', 'curb', 'tie-up', 'tie-ups', 'familiar with the development', 'familiar with the matter', 'Anonymous', 'anonymity', 'Rumour', 'Scam', 'Fraud', 'In talks', 'Likely to', 'Cancel', 'May consider', 'may enter', 'may seal', 'may cancel', 'Plans to', 'Raids', 'raid', 'search', 'Delisting', 'delist', 'puts on the Block', 'put on the block', 'Exit', 'Cheating', 'Scouts', 'scouting', 'Default', 'defaulted', 'defaulter', 'Calls off', 'Lease out', 'Pick up', 'delay', 'arrest', 'arrested', 'arrest warrant', 'inks', 'in race', 'enters race', 'mull', 'final stage', 'final deal', 'eye', 'eyes', 'eyeing', 'probe', 'vie for', 'detects', 'allege', 'alleges', 'alleged', 'inspection', 'inspected', 'to monetise', 'cancellation', 'control', 'pact', 'warning', 'IT scanner', 'divest', 'sets aside', 'hiking stake', 'gets nod for', 'joint venture', 'nod for', 'to acquire', 'acquisition', 'acquired', 'wins', 'acquires', 'may acquire', 'may get', 'bag', 'ink', 'familiar with the deal', 'planned', 'appointed', 'appointment', 'sale', 'capital infusion', 'deal', 'planning to', 'expansion', 'to expand', 'to raise', 'raised', 'started work', 'investment', 'to invest', 'invests', 'approvals', 'approval', 'to set up', 'setting up', 'buyback', 'weak performance', 'aiming at', 'aim to', 'aims to', 'sold', 'court', 'verdict', 'merger', 'to merge', 'merges', 'announced', 'to announce', 'results', 'q1', 'q2', 'q3', 'q4', 'launch', 'launched', 'launches', 'to sell', 'sold', 'sells', 'allots', 'alloted', 'offered', 'taken over', 'settlement', 'settle', 'settles', 'give up', 'gives up', 'has given up', 'resigns', 'resigned', 'to resign', 'opens', 'to open', 'opened', 'has been named', 'award', 'awarded', 'suspends', 'suspended', 'to suspend', 'scam', 'bags order', 'bags deal', 'quits', 'to quit', 'snaps up', 'racket', 'funding', 'notice', 'to cost', 'announces', 'agreement', 'tie up', 'may sell', 'finalize deal', 'may be given', 'halted', 'to consider', 'to also consider', 'fire', 'allegations', 'takeover', 'to accept', 'offer', 'contract', 'US_FDA', 'USFDA', 'profit', 'to approve', 'sell stake','punishment','fine','price','dues','damage','slap','penalty','reward','gain','benefit','advantage','allegation','accusation','plea','charge','charged','affirmation','deposition','looting','big bang','merging','merged','absorb','absorbed','consolidate','competition','struggle','struggled','venture','endeavor','experiment','project','undertaking','proposition','speculation','paid','pay','paying','compensated','.*[^a-zA-Z]buy.*[^a-zA-Z]target[^a-zA-Z].*','.*[^a-zA-Z]buy.*[^a-zA-Z]trgt[^a-zA-Z].*','.*[^a-zA-Z]buy.*[^a-zA-Z]cmp[^a-zA-Z].*','.*[^a-zA-Z]buy.*[^a-zA-Z]tgt[^a-zA-Z].*','.*[^a-zA-Z]buy.*[^a-zA-Z]sl[^a-zA-Z].*','.*[^a-zA-Z]sell.*[^a-zA-Z]target[^a-zA-Z].*','.*[^a-zA-Z]sell.*[^a-zA-Z]trgt[^a-zA-Z].*','.*[^a-zA-Z]sell.*[^a-zA-Z]sl[^a-zA-Z].*','.*[^a-zA-Z]sell.*[^a-zA-Z]cmp[^a-zA-Z].*','.*[^a-zA-Z]sell.*[^a-zA-Z]tgt[^a-zA-Z].*','www.bsebull.in','VM - StAxis','VM - BSEBUL','www.stockaxis.com','www.goldenstock.in','spanning','targeting','growing','expect','capture','reinvent','growth','to enter','entered into','being acquired']
      #removed "india" from two gram list, issue Rolta India was used as rolta which skipped due to in 2gram
      companies_set_pickle = open("company_grams.pickle")
      companies_set = pickle.load(companies_set_pickle)
      companies_set_pickle.close()
      for line in sys.stdin:
         try:
                if len(line) == 0: continue
                l =line.strip()
                m = l.split('||#||')
                ids=m[0]
                retweet_count=m[1]
                favorite_count=m[2]
                created_at=m[3]
                text=m[4]
                time_stamp=m[5]
                user_name=m[6]
                flag=0
                text=' '+text.decode('utf-8','ignore').encode('ascii','ignore')
                import pdb
                total = 0
                filter_company_level = 0
                cname = []
                final_result = []
                company_list_present = set()
                string.replace(text , ' & ', ' and ')
                for word in rumour_keywords:
		       if bool(re.search(word.lower(),u'{}'.format(text).lower())):
                       #if word.lower() in u'{}'.format(text).lower():
                            flag=2
                            break
                if flag == 2 :
                     for company_details in companies_set:
                                for company_gram,company_name in company_details.iteritems():
                                        try:
                                                company_gram=string.replace(company_gram,' & ',' and ').lower()
                                                if '@' + company_gram.lower()+' ' in u'{}'.format(text).lower() or '#' + company_gram.lower()+'\'s' in  u'{}'.format(text).lower() or ' ' + company_gram.lower()+'\'s' in  u'{}'.format(text).lower() or '#' + company_gram.lower()+' ' in u'{}'.format(text).lower() or ' ' + company_gram.lower()+' ' in u'{}'.format(text).lower() or ' ' + company_gram.lower()+'.' in u'{}'.format(text).lower() or '.' + company_gram.lower()+' ' in u'{}'.format(text).lower():
                                                            if company_name[-1:] == '.':
                                                                    company_list_present.add(company_name[:-1])
                                                                    flag = 1
                                                            else:
                                                                     company_list_present.add(company_name)
                                                            flag = 1
                                        except:
                                                import traceback
                                                continue
		     if len(company_list_present)==0:
		         flag=4
                     print ids+"||#||"+retweet_count+"||#||"+favorite_count+"||#||"+created_at+"||#||"+text+"||#||"+time_stamp+"||#||"+user_name+"||#||"+str(flag)+"||#||"+",".join(company_list_present)
                elif flag == 0:
                         print ids+"||#||"+retweet_count+"||#||"+favorite_count+"||#||"+created_at+"||#||"+text+"||#||"+time_stamp+"||#||"+user_name+"||#||"+"3"+"||#||"+",".join(company_list_present)
         except:
                  import traceback
                  print "0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0"#traceback.format_exc()
                  print traceback.format_exc()
                  #continue

except:
         import traceback
         #print  "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
         print traceback.format_exc()
