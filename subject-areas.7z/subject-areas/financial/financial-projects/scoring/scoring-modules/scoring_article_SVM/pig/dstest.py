#!/opt/Python-2.7.6/python
from sklearn.utils import check_random_state
from sklearn.datasets import load_files
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC 
from fuzzywuzzy import fuzz
from sklearn.metrics import accuracy_score, average_precision_score, f1_score, precision_score, recall_score
from sklearn.externals import joblib
from sklearn.feature_extraction.text import FeatureHasher
from nltk.corpus import stopwords
from nltk.stem.lancaster import LancasterStemmer
from nltk.tokenize import word_tokenize
import nltk
import numpy as np
from time import time
import pprint
import pickle
import nltk
import os
import sys
import string
sys.path.append(".")
i = 0



def token_ques(text):
    things_to_replace = ['?']
    things_to_replace += stopwords.words('english')
    #wh_word = None
    for tok in text.split('\n'):
        original_query = tok
        # 1. Stemming
        # 2. POS consideration verb, adjectives
        query_pos_tags = nltk.pos_tag(word_tokenize(tok))     
        for word in things_to_replace:
             tok = tok.lower()
                #tok = re.sub("\s"+word+"\s|\s?"+"\?"+"$",' ',tok)
             tok = tok.strip("  ")
                # tok = tok.lstrip(" ")
                # tok = tok.rstrip(" ")
        for word in word_tokenize(tok):
             yield word.lower()
  


try:
	t1 = time()
	start_time = time()
	#vectorizer = HashingVectorizer(non_negative=True)
	#vectorizer = CountVectorizer(non_negative=True,tokenizer=my_tokenizer)
	hasher = FeatureHasher(input_type='string',non_negative=True)
	clf = SVC(probability=True,C=5., gamma=0.001)
        #pdb.set_trace()
        rumour_keywords = ['Buzz', 'Heard on the street', 'tie up', 'curbs', 'curb', 'tie-up', 'tie-ups', 'familiar with the development', 'familiar with the matter', 'Anonymous', 'anonymity', 'Rumour', 'Scam', 'Fraud', 'In talks', 'Likely to', 'Cancel', 'May consider', 'may enter', 'may seal', 'may cancel', 'Plans to', 'Raids', 'raid', 'search', 'Delisting', 'delist', 'puts on the Block', 'put on the block', 'Exit', 'Cheating', 'Scouts', 'scouting', 'Default', 'defaulted', 'defaulter', 'Calls off', 'Lease out', 'Pick up', 'delay', 'arrest', 'arrested', 'arrest warrant', 'inks', 'in race', 'enters race', 'mull', 'final stage', 'final deal', 'eye', 'eyes', 'eyeing', 'probe', 'vie for', 'detects', 'allege', 'alleges', 'alleged', 'inspection', 'inspected', 'to monetise', 'cancellation', 'control', 'pact', 'warning', 'IT scanner', 'divest', 'sets aside', 'hiking stake', 'gets nod for', 'joint venture', 'nod for', 'to acquire', 'acquisition', 'acquired', 'wins', 'acquires', 'may acquire', 'may get', 'bag', 'ink', 'familiar with the deal', 'planned', 'appointed', 'appointment', 'sale', 'capital infusion', 'deal', 'planning to', 'expansion', 'to expand', 'to raise', 'raised', 'started work', 'investment', 'to invest', 'invests', 'approvals', 'approval', 'to set up', 'setting up', 'buyback', 'weak performance', 'aiming at', 'aim to', 'aims to', 'sold', 'court', 'verdict', 'merger', 'to merge', 'merges', 'announced', 'to announce', 'results', 'q1', 'q2', 'q3', 'q4', 'launch', 'launched', 'launches', 'to sell', 'sold', 'sells', 'allots', 'alloted', 'offered', 'taken over', 'settlement', 'settle', 'settles', 'give up', 'gives up', 'has given up', 'resigns', 'resigned', 'to resign', 'opens', 'to open', 'opened', 'has been named', 'award', 'awarded', 'suspends', 'suspended', 'to suspend', 'scam', 'bags order', 'bags deal', 'quits', 'to quit', 'snaps up', 'racket', 'funding', 'notice', 'to cost','produce','produced','manufacture','manufactured','punishment','fine','price','dues','damage','slap','penalty','reward','gain','benefit','advantage','spanning','targeting','growing','expect','capture','reinvent','growth','to enter','entered into','being acquired']
 	X_train = pickle.load(open("x_svm_result.pickle", "rb" ) )
	y_train = pickle.load(open("y_svm_result.pickle", "rb" ) )
	clf.fit(X_train, y_train)
        processed_title = []
	for line in sys.stdin:
		try:
                	if len(line) == 0: continue 
			l =line.strip()
			m = l.split('#DMBSE') 
			ids=m[0]
	 		title=m[1]
	 		query= title + ' ' + m[2]
	        	published=m[3]
	 		unread=m[4]
			link=m[5]
			source=m[6]
			company_list_present=m[7]
                	query = query.decode('utf-8','ignore').encode('ascii','ignore')
			result =""
        		test_data = [query]
			raw_X = (token_ques(text) for text in test_data)
			X_test = hasher.fit_transform(raw_X)
                        dup_flag=0
			rumour_keyword_present=""
                        pred = clf.predict(X_test)
			categories = ['suspected', 'unsuspected']

			predict_prob = clf.predict_proba(X_test)
			for doc, category_list in zip(test_data, predict_prob):
   			 	category_list = enumerate(category_list)
    			 	i = 0
    			 	for val in category_list:
					result=result+str((float(val[1]) * 100))
					if(i<1):
						result=result+'#DMBSE'
 					i=i+1
			if result.split('#DMBSE')[0] > result.split('#DMBSE')[1]:
                              dup_flag = 0
	                      for title_in_for in processed_title:
		                    if fuzz.ratio(title, title_in_for)> 80:
			                   dup_flag = 1
			                   break
                              processed_title.append(title)
                        for word in rumour_keywords:
                        	if word.lower() in u'{} {}'.format(title,query).lower():
                                	rumour_keyword_present=rumour_keyword_present+word+','
                        result=ids+"#DMBSE"+title+"#DMBSE"+m[2]+'#DMBSE'+published+"#DMBSE"+unread+"#DMBSE"+link+"#DMBSE"+source+"#DMBSE"+result+"#DMBSE"+company_list_present+"#DMBSE"+rumour_keyword_present+"#DMBSE"+str(dup_flag)
			print result
		except:	
			import traceback
                  	#print "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
                  	print traceback.format_exc() 
                  	continue

except Exception, err:
                         import traceback
                         sys.stderr.write('ERROR: %sn' % str(err)) 
