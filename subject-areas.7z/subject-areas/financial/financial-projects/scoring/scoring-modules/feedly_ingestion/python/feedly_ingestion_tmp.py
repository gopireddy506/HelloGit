#!/opt/Python-2.7.6/python
import requests
import json
import numpy as np
import ConfigParser
import datetime
import sys

i=0
def get_user_subscriptions(url,access_token):
       '''return list of user subscriptions'''
       headers = {'Authorization': 'OAuth '+access_token}
       quest_url=url+'/v3/subscriptions'
       proxies = {'http': 'http://192.168.246.9:8080'}
       res = requests.get(url=quest_url, headers=headers,proxies=proxies)
       return res.json()


try:
	arg=sys.argv
	cf = ConfigParser.ConfigParser()
	cf.read(arg[1])
	url =cf.get("feedly", "url")
	jsurl =cf.get("feedly", "jsurl")
	count =cf.get("feedly", "count")
	keyLocation=cf.get("feedly", "keyLocation")
	markurl=cf.get("feedly", "markurl")
	globalId=cf.get("feedly", "globalId")
	with open(keyLocation) as f:
   		 lines = f.readlines()
	data=[]
	headers = {'Authorization' : 'OAuth '+lines[0].replace('\n','')}
	headers['Content-Type'] = "application/json"
	get_subscription_ids = requests.get(url, headers = headers).json()
        #print get_subscription_ids
	cur_time=datetime.datetime.now()
	dels=len(get_subscription_ids)
	articleId=get_subscription_ids['items'][0]['id']
	#print articleId
        sub=get_user_subscriptions("http://cloud.feedly.com",lines[0])
        #print sub
        json_data=[]
	filename=arg[2]+cf.get("feedly", "filename")+str(cur_time.year)+str(cur_time.month)+str(cur_time.day)+str(cur_time.hour)+str(cur_time.minute)+str(cur_time.second)
	while 1:
			if get_subscription_ids.get('continuation'):
        			continuation=get_subscription_ids['continuation'].encode('utf-8','strict')
				filenames=filename+str(i)
				i=i+1
				try:
					with open(filenames, 'wb') as outfile:
    						json.dump(get_subscription_ids, outfile)
					
				except:
              				#print 'file path does not exist in if '+arg[2]
					import traceback
					traceback.print_exc()
				newurl=url+"&continuation="+continuation
				get_subscription_ids=requests.get(newurl, headers = headers).json()
				continue
    			else:
				i=i+1
				filenames=filename+str(i)
				payload={"type":"categories","action": "markAsRead","categoryIds":[globalId],"lastReadEntryId":articleId}
				r = requests.post(markurl, data =json.dumps(payload) ,headers = headers)
				print r
				
				try:
					with open(filename, 'wb') as outfile1:
    						json.dump(get_subscription_ids, outfile1)
				except:
              				print 'file path does not exist in else '+arg[2]
    				break

except:
      import traceback
      print traceback.format_exc()
      #print "please check argument is passed in order python test.py test.properties folderlocation"

