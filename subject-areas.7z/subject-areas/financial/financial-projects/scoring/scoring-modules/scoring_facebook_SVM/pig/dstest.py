#!/opt/Python-2.7.6/python
from sklearn.utils import check_random_state
from sklearn.datasets import load_files
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC
from fuzzywuzzy import fuzz
from sklearn.metrics import accuracy_score, average_precision_score, f1_score, precision_score, recall_score
from sklearn.externals import joblib
from sklearn.feature_extraction.text import FeatureHasher
from nltk.corpus import stopwords
from nltk.stem.lancaster import LancasterStemmer
from nltk.tokenize import word_tokenize
import nltk
import numpy as np
from time import time
import pprint
import pickle
import nltk
import os
import sys
import string
sys.path.append(".")
i = 0


def token_ques(message):
    things_to_replace = ['?']
    things_to_replace += stopwords.words('english')
    #wh_word = None
    for tok in message.split('\n'):
        original_query = tok
        # 1. Stemming
        # 2. POS consideration verb, adjectives
        query_pos_tags = nltk.pos_tag(word_tokenize(tok))
        for word in things_to_replace:
             tok = tok.lower()
                #tok = re.sub("\s"+word+"\s|\s?"+"\?"+"$",' ',tok)
             tok = tok.strip("  ")
                # tok = tok.lstrip(" ")
                # tok = tok.rstrip(" ")
        for word in word_tokenize(tok):
             yield word.lower()



try:
        t1 = time()
        start_time = time()
        #vectorizer = HashingVectorizer(non_negative=True)
        #vectorizer = CountVectorizer(non_negative=True,tokenizer=my_tokenizer)
        hasher = FeatureHasher(input_type='string',non_negative=True)
        clf = SVC(probability=True,C=5., gamma=0.001)

        #pdb.set_trace()

        X_train = pickle.load(open("x_facebook_result.pickle", "rb") )
        y_train = pickle.load(open("y_facebook_result.pickle", "rb") )
        clf.fit(X_train, y_train)
        processed_title = []
        for line in sys.stdin:
                try:
                        if len(line) == 0: continue
                        l =line.strip()
                        m = l.split('||#||')
                        id=m[0]
			message=m[1]
			created_time=m[2]
			link=m[3]
			source_link=m[4]
			like_count=m[5]
			comments_messages=m[6]
			comments_count=m[7]
			company_list_present=m[8]
                        message = message.decode('utf-8','ignore').encode('ascii','ignore')
                        result = ""
                        test_data = [message]
                        raw_X = (token_ques(message1) for message1 in test_data)
                        X_test = hasher.fit_transform(raw_X)
                        dup_flag=0
                        pred = clf.predict(X_test)
                        categories = ['suspected', 'unsuspected']

                        predict_prob = clf.predict_proba(X_test)
                        for doc, category_list in zip(test_data, predict_prob):
                                category_list = enumerate(category_list)
                                i = 0
                                for val in category_list:
                                        result=result+str((float(val[1]) * 100))
                                        if(i<1):
                                                result=result+'||#||'
                                        i=i+1
                        if result.split('||#||')[0] > result.split('||#||')[1]:
                              dup_flag = 0
                              for title_in_for in processed_title:
                                    if fuzz.ratio(message,title_in_for)> 80:
                                           dup_flag = 1
                                           break
                              processed_title.append(message)
                        result=id+"||#||"+message+"||#||"+created_time+"||#||"+link+"||#||"+source_link+"||#||"+like_count+"||#||"+comments_messages+"||#||"+comments_count+"||#||"+company_list_present+"||#||"+result+"||#||"+str(dup_flag)
                        print result
                except:
			print "0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0"
                        #import traceback
                        #print traceback.format_exc()
                        continue
except Exception, err:
                         import traceback
                         sys.stderr.write('ERROR: %sn' % str(err))
