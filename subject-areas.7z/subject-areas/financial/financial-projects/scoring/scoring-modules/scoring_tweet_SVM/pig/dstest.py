#!/opt/Python-2.7.6/python
from sklearn.utils import check_random_state
from sklearn.datasets import load_files
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC 
from fuzzywuzzy import fuzz
from sklearn.metrics import accuracy_score, average_precision_score, f1_score, precision_score, recall_score
from sklearn.externals import joblib
from sklearn.feature_extraction.text import FeatureHasher
from nltk.corpus import stopwords
from nltk.stem.lancaster import LancasterStemmer
from nltk.tokenize import word_tokenize
import nltk
import numpy as np
from time import time
import pprint
import pickle
import nltk
import os
import sys
import string
import re
sys.path.append(".")
i = 0



def token_ques(text):
    things_to_replace = ['?']
    things_to_replace += stopwords.words('english')
    #wh_word = None
    for tok in text.split('\n'):
        original_query = tok
        # 1. Stemming
        # 2. POS consideration verb, adjectives
        query_pos_tags = nltk.pos_tag(word_tokenize(tok))     
        for word in things_to_replace:
             tok = tok.lower()
                #tok = re.sub("\s"+word+"\s|\s?"+"\?"+"$",' ',tok)
             tok = tok.strip("  ")
                # tok = tok.lstrip(" ")
                # tok = tok.rstrip(" ")
        for word in word_tokenize(tok):
             yield word.lower()
  


try:
	t1 = time()
	start_time = time()
	#vectorizer = HashingVectorizer(non_negative=True)
	#vectorizer = CountVectorizer(non_negative=True,tokenizer=my_tokenizer)
	hasher = FeatureHasher(input_type='string',non_negative=True)
	clf = SVC(probability=True,C=5., gamma=0.001)

	#pdb.set_trace()


	X_train = pickle.load(open("x_twitter_result.pickle", "rb" ) )
	y_train = pickle.load(open("y_twitter_result.pickle", "rb" ) )
	clf.fit(X_train, y_train)
        processed_title = []
	for line in sys.stdin:
		try:
                	if len(line) == 0: continue 
			l =line.strip()
			m = l.split('||#||') 
			ids=m[0]
	 		retweet_count=m[1]
	 		favorite_count=m[2]
	        	created_at=m[3]
	 		text=m[4]
			time_stamp=m[5]
			user_name=m[6]
                        company_list_present=m[7]
                	text = text.decode('utf-8','ignore').encode('ascii','ignore')
			result =""
        		test_data = [re.sub(r"http\S+", "",text)]
			raw_X = (token_ques(text1) for text1 in test_data)
			X_test = hasher.fit_transform(raw_X)
                        dup_flag=0
			pred = clf.predict(X_test)
			categories = ['suspected', 'unsuspected']

			predict_prob = clf.predict_proba(X_test)
			for doc, category_list in zip(test_data, predict_prob):
   			 	category_list = enumerate(category_list)
    			 	i = 0
    			 	for val in category_list:
					result=result+str((float(val[1]) * 100))
					if(i<1):
						result=result+'||#||'
 					i=i+1
			if result.split('||#||')[0] > result.split('||#||')[1]:
                              dup_flag = 0
	                      for title_in_for in processed_title:
		                    if fuzz.ratio(text,title_in_for)> 80:
			                   dup_flag = 1
			                   break
                              processed_title.append(text)
                        result=ids+"||#||"+retweet_count+"||#||"+favorite_count+'||#||'+created_at+"||#||"+text+"||#||"+time_stamp+"||#||"+user_name+"||#||"+company_list_present+"||#||"+result+"||#||"+str(dup_flag)
			print result
		except:	
			"0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0"
			#import traceback
                  	#print "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
                  	#print traceback.format_exc() 
                  	continue

except Exception, err:
                         import traceback
                         sys.stderr.write('ERROR: %sn' % str(err)) 
