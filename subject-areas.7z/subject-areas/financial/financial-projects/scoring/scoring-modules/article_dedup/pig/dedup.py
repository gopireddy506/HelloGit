#!/opt/Python-2.7.6/python
from fuzzywuzzy import fuzz
from time import time
import pprint
import os
import sys
import string
sys.path.append(".")
i = 0



try:
        processed_title = []
        for line in sys.stdin:
                try:
                        if len(line) == 0: continue
                        l =line.strip()
                        m = l.split('#DMBSE')
                        ids=m[0]
                        title=m[1]
                        content=m[2]
                        published=m[3]
                        unread=m[4]
                        link=m[5]
                        source=m[6]
                        suspected=m[7]
                        unsuspected=m[8]
                        company_list_present=m[9]
                        rumour_keywords_present=m[10]
                        batch_id=m[11]
                        if title:
                              dup_flag='0'
                              for title_in_for in processed_title:
                                    if fuzz.ratio(title, title_in_for)> 80:
                                           dup_flag='1'
                                           break
                        processed_title.append(title)
                        result=ids+'#DMBSE'+title+'#DMBSE'+content+'#DMBSE'+published+'#DMBSE'+unread+'#DMBSE'+link+'#DMBSE'+source+'#DMBSE'+suspected+'#DMBSE'+unsuspected+'#DMBSE'+str(company_list_present)+'#DMBSE'+rumour_keywords_present+'#DMBSE'+batch_id+'#DMBSE'+str(dup_flag)
                        print result
                except:
                        import traceback
                        print "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
                        #print traceback.format_exc()
                        continue

except Exception, err:
                         import traceback
                         sys.stderr.write('ERROR: %sn' % str(err))

