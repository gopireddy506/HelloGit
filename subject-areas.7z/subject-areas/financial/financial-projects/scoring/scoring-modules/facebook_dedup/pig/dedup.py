#!/opt/Python-2.7.6/python
from fuzzywuzzy import fuzz
from time import time
import pprint
import os
import sys
import string
sys.path.append(".")
i = 0



try:
        processed_tweets = []
        for line in sys.stdin:
                try:
                        if len(line) == 0: continue
                        l =line.strip()
                        m = l.split('#DMBSE')
                        tweet=m[1]
                        if tweet:
                              dup_flag='0'
                              for  processed_tweet in processed_tweets:
                                    if fuzz.token_sort_ratio(tweet, processed_tweet)> 85:
                                           dup_flag='1'
                                           break
                        processed_tweets.append(tweet)
                        result=l+'#DMBSE'+str(dup_flag)
                        print result
                except:
                        #import traceback
			print "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"
			#print "null#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSEnull#DMBSE#DMBSEnull#DMBSEnull"
                        #print traceback.format_exc()
                        continue

except Exception, err:
                         import traceback
                         sys.stderr.write('ERROR: %sn' % str(err))

