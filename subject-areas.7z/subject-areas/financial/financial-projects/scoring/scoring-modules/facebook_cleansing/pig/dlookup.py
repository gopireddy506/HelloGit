#!/opt/Python-2.7.6/python
import pickle
from nltk.util import ngrams
import re, pickle
import os
import sys
import string
import time

try:
      rumour_keywords = ['Buzz', 'Heard on the street', 'tie up', 'curbs', 'curb', 'tie-up', 'tie-ups', 'familiar with the development', 'familiar with the matter', 'Anonymous', 'anonymity', 'Rumour', 'Scam', 'Fraud', 'In talks', 'Likely to', 'Cancel', 'May consider', 'may enter', 'may seal', 'may cancel', 'Plans to', 'Raids', 'raid', 'search', 'Delisting', 'delist', 'puts on the Block', 'put on the block', 'Exit', 'Cheating', 'Scouts', 'scouting', 'Default', 'defaulted', 'defaulter', 'Calls off', 'Lease out', 'Pick up', 'delay', 'arrest', 'arrested', 'arrest warrant', 'inks', 'in race', 'enters race', 'mull', 'final stage', 'final deal', 'eye', 'eyes', 'eyeing', 'probe', 'vie for', 'detects', 'allege', 'alleges', 'alleged', 'inspection', 'inspected', 'to monetise', 'cancellation', 'control', 'pact', 'warning', 'IT scanner', 'divest', 'sets aside', 'hiking stake', 'gets nod for', 'joint venture', 'nod for', 'to acquire', 'acquisition', 'acquired', 'wins', 'acquires', 'may acquire', 'may get', 'bag', 'ink', 'familiar with the deal', 'planned', 'appointed', 'appointment', 'sale', 'capital infusion', 'deal', 'planning to', 'expansion', 'to expand', 'to raise', 'raised', 'started work', 'investment', 'to invest', 'invests', 'approvals', 'approval', 'to set up', 'setting up', 'buyback', 'weak performance', 'aiming at', 'aim to', 'aims to', 'sold', 'court', 'verdict', 'merger', 'to merge', 'merges', 'announced', 'to announce', 'results', 'q1', 'q2', 'q3', 'q4', 'launch', 'launched', 'launches', 'to sell', 'sold', 'sells', 'allots', 'alloted', 'offered', 'taken over', 'settlement', 'settle', 'settles', 'give up', 'gives up', 'has given up', 'resigns', 'resigned', 'to resign', 'opens', 'to open', 'opened', 'has been named', 'award', 'awarded', 'suspends', 'suspended', 'to suspend', 'scam', 'bags order', 'bags deal', 'quits', 'to quit', 'snaps up', 'racket', 'funding', 'notice', 'to cost', 'announces', 'agreement', 'tie up', 'may sell', 'finalize deal', 'may be given', 'halted', 'to consider', 'to also consider', 'fire', 'allegations', 'takeover', 'to accept', 'offer', 'contract', 'US_FDA', 'USFDA', 'profit', 'to approve', 'sell stake',  'punishment','fine','price','dues','damage','slap','penalty','reward','gain','benefit','advantage','allegation','accusation','plea','charge','charged','affirmation','deposition','looting','big bang','merging','merged','absorb','absorbed','consolidate','competition','struggle','struggled','venture','endeavor','experiment','project','undertaking','proposition','speculation','paid','pay','paying','compensated','spanning','targeting','growing','expect','capture','reinvent','growth','to enter','entered into','being acquired']
      #removed "india" from two gram list, issue Rolta India was used as rolta which skipped due to in 2gram
      companies_set_pickle = open("company_grams.pickle")
      companies_set = pickle.load(companies_set_pickle)
      companies_set_pickle.close()
      for line in sys.stdin:
         try:
                if len(line) == 0: continue
                l =line.strip()
                m = l.split('||#||')
                id=m[0]
                message=m[1]
                created_time=m[2]
                link=m[3]
		source_link=m[4]
                like_count=m[5]
                comments_messages=m[6].decode('utf-8','ignore').encode('ascii','ignore')
		comments_count=m[7]
                flag=0
                message=' '+message.decode('utf-8','ignore').encode('ascii','ignore')
		formatted_message=u'{}'.format(message).lower()
                company_list_present = set()
                string.replace(message , ' & ', ' and ')
		for word in rumour_keywords:
                       if word.lower() in u'{}'.format(message).lower():
                            flag=2
                            break
                if flag == 2 :
			for company_details in companies_set:
				for company_gram,company_name in company_details.iteritems():
					try:
						company_gram=string.replace(company_gram,' & ',' and ').lower()
						if  '@' + company_gram +' ' in formatted_message or '#' + company_gram +'\'s' in  formatted_message or ' ' + company_gram +'\'s' in  formatted_message or '#' + company_gram +' ' in formatted_message or ' ' + company_gram +' ' in formatted_message or ' ' + company_gram +'.' in formatted_message or '.' + company_gram +' ' in formatted_message:
							if company_name[-1:]=='.':
								company_list_present.add(company_name[:-1])
							else:
								company_list_present.add(company_name)
							flag=1
					except:
						continue
			if len(company_list_present) == 0:
				flag=4
	        elif flag == 0:
                        flag=3 
		if flag != 1:
			raw_comments=re.split("\x01",comments_messages)
			comments_keywords_present=set()
			comments_company_present=set()
			for raw_comment in raw_comments:
				for keyword in rumour_keywords:
					if keyword.lower() in u'{}'.format(raw_comment).lower():
						comments_keywords_present.add(raw_comment)
						break

			for comment in comments_keywords_present:
				formatted_comment=u'{}'.format(comment).lower()
				for company_details in companies_set:
					for company_gram,company_name in company_details.iteritems():
						try:
							company_gram=string.replace(company_gram,' & ',' and ').lower()
							if  '@' + company_gram +' ' in formatted_comment or '#' + company_gram +'\'s' in  formatted_comment or ' ' + company_gram +'\'s' in  formatted_comment or '#' + company_gram +' ' in formatted_comment or ' ' + company_gram +' ' in formatted_comment or ' ' + company_gram +'.' in formatted_comment or '.' + company_gram +' ' in formatted_comment:
                                                        	if company_name[-1:]=='.':
                                                                	company_list_present.add(company_name[:-1])
                                                        	else:
                                                                	company_list_present.add(comapny_name)
                                                        	flag=5
								comments_company_present.add(comment)
						except:
							continue
			if flag == 5:
				comments_messages="\x01".join(comments_company_present)
		print id+"||#||"+message+"||#||"+created_time+"||#||"+link+"||#||"+source_link+"||#||"+like_count+"||#||"+comments_messages+"||#||"+comments_count+"||#||"+str(flag)+"||#||"+",".join(company_list_present)
		
         except:
                  import traceback
                  print "0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0||#||0"#traceback.format_exc()
                  #print traceback.format_exc()
                  #continue
except:
         import traceback
         #print  "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
         print traceback.format_exc()

