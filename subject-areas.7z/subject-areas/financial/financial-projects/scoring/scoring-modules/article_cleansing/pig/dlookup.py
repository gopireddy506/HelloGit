#!/opt/Python-2.7.6/python
import pickle
from nltk.util import ngrams
import re, pickle
import os
import sys
import string

def get_company_alias(cname):
	rmv = ['ltd','limited.','limited','ltd.', 'corporat', 'corpn', 'lt', 'l']
	sentence_list = cname.lower().split(' ')
	for val in sentence_list:
		if val in rmv:
			sentence_list.remove(val)
	cname = ' '.join(sentence_list)
	return cname


try:
	rumour_keywords = ['Buzz', 'Heard on the street', 'tie up', 'curbs', 'curb', 'tie-up', 'tie-ups', 'familiar with the development', 'familiar with the matter', 'Anonymous', 'anonymity', 'Rumour', 'Scam', 'Fraud', 'In talks', 'Likely to', 'Cancel', 'May consider', 'may enter', 'may seal', 'may cancel', 'Plans to', 'Raids', 'raid', 'search', 'Delisting', 'delist', 'puts on the Block', 'put on the block', 'Exit', 'Cheating', 'Scouts', 'scouting', 'Default', 'defaulted', 'defaulter', 'Calls off', 'Lease out', 'Pick up', 'delay', 'arrest', 'arrested', 'arrest warrant', 'inks', 'in race', 'enters race', 'mull', 'final stage', 'final deal', 'eye', 'eyes', 'eyeing', 'probe', 'vie for', 'detects', 'allege', 'alleges', 'alleged', 'inspection', 'inspected', 'to monetise', 'cancellation', 'control', 'pact', 'warning', 'IT scanner', 'divest', 'sets aside', 'hiking stake', 'gets nod for', 'joint venture', 'nod for', 'to acquire', 'acquisition', 'acquired', 'wins', 'acquires', 'may acquire', 'may get', 'bag', 'ink', 'familiar with the deal', 'planned', 'appointed', 'appointment', 'sale', 'capital infusion', 'deal', 'planning to', 'expansion', 'to expand', 'to raise', 'raised', 'started work', 'investment', 'to invest', 'invests', 'approvals', 'approval', 'to set up', 'setting up', 'buyback', 'weak performance', 'aiming at', 'aim to', 'aims to', 'sold', 'court', 'verdict', 'merger', 'to merge', 'merges', 'announced', 'to announce', 'results', 'q1', 'q2', 'q3', 'q4', 'launch', 'launched', 'launches', 'to sell', 'sold', 'sells', 'allots', 'alloted', 'offered', 'taken over', 'settlement', 'settle', 'settles', 'give up', 'gives up', 'has given up', 'resigns', 'resigned', 'to resign', 'opens', 'to open', 'opened', 'has been named', 'award', 'awarded', 'suspends', 'suspended', 'to suspend', 'scam', 'bags order', 'bags deal', 'quits', 'to quit', 'snaps up', 'racket', 'funding', 'notice', 'to cost','produce','produced','manufacture','manufactured','punishment','fine','price','dues','damage','slap','penalty','reward','gain','benefit','advantage','spanning','targeting','growing','expect','capture','reinvent','growth','to enter','entered into','being acquired']

	#removed "india" from two gram list, issue Rolta India was used as rolta which skipped due to in 2gram
	#company_reconsider_upper_case = ['LIC']
	#keyword_remove = ['ltd.', 'limited','private','pvt']
	companies_set_pickle = open("company_grams.pickle")
	companies_set = pickle.load(companies_set_pickle)
	companies_set_pickle.close()

	for line in sys.stdin:
		try:
			if len(line) == 0: continue
			l =line.strip()
			m = l.split('#DMBSE')
			ids=m[0]
			title=m[1]
			query=m[2]
			published=m[3]
			unread=m[4]
			link=m[5]
			source=m[6]
			flag=0
			query=' '+query.decode('utf-8','ignore').encode('ascii','ignore')
			title=' '+title.decode('utf-8','ignore').encode('ascii','ignore')
			import pdb
			total = 0
			filter_company_level = 0
			cname = []
			final_result = []
			string.replace(title , ' & ', ' and ')
			string.replace(query , ' & ', ' and ')
			company_list_present = set()
			for word in rumour_keywords:
				if word.lower() in u'{} {}'.format(title,query).lower():
					flag=2
					break
			if flag == 2 :
				for company_details in companies_set:
					for company_gram, company_name in company_details.iteritems():
						try:
							company_gram = string.replace(company_gram, ' & ', ' and ').lower()
							if ' ' + company_gram + ' ' in u'{} {}'.format(title,query).lower() or ' ' + company_gram + '.' in u'{} {}'.format(title, query).lower() or '.' + company_gram + ' ' in u'{} {}'.format(title, query).lower():
								if company_name[-1:] == '.':
									company_list_present.add(company_name[:-1])
								else:
									company_list_present.add(company_name)
								flag = 1
						except:
							import traceback
							continue
				if len(company_list_present) == 0:
					flag = 4
				print ids+"#DMBSE"+title+"#DMBSE"+query+"#DMBSE"+published+"#DMBSE"+unread+"#DMBSE"+link+"#DMBSE"+source+"#DMBSE"+str(flag)+"#DMBSE"+",".join(company_list_present)
			elif flag == 0:
				print ids+"#DMBSE"+title+"#DMBSE"+query+"#DMBSE"+published+"#DMBSE"+unread+"#DMBSE"+link+"#DMBSE"+source+"#DMBSE"+"3"+"#DMBSE"+",".join(company_list_present)
		except:
			import traceback
			print "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
			#print traceback.format_exc()
			#continue

except:
	import traceback
	#print  "0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0#DMBSE0"#traceback.format_exc()
	print traceback.format_exc()

