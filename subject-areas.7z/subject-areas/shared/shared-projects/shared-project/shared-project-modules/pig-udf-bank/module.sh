################################################################################
#                               General Details                                #
################################################################################
#                                                                              #
# Name                                                                         #
#     : membership_coverage_events                                             #
# File                                                                         #
#     : module.sh                                                              #
#                                                                              #
# Description                                                                  #
#     : This shell script executes all code related to                         #
#       membership_coverage_events module                                      #
#                                                                              #
#                                                                              #
# Author                                                                       #
#     : Chanchal Singh                                             #
#                                                                              #
################################################################################
#                           Script Environment Setup                           #
################################################################################
#set -x
#Find the script file home
pushd . > /dev/null
SCRIPT_HOME="${BASH_SOURCE[0]}";
while([ -h "${SCRIPT_HOME}" ]); do
    cd "`dirname "${SCRIPT_HOME}"`"
    SCRIPT_HOME="$(readlink "`basename "${SCRIPT_HOME}"`")";
done
cd "`dirname "${SCRIPT_HOME}"`" > /dev/null
SCRIPT_HOME="`pwd`";
popd  > /dev/null

#set all parent home environment variables
MODULE_HOME=`dirname ${SCRIPT_HOME}`
MODULES_HOME=`dirname ${MODULE_HOME}`
PROJECT_HOME=`dirname ${MODULES_HOME}`
PROJECTS_HOME=`dirname ${PROJECT_HOME}`
SUBJECT_AREA_HOME=`dirname ${PROJECTS_HOME}`
SUBJECT_AREAS_HOME=`dirname ${SUBJECT_AREA_HOME}`
HOME=`dirname ${SUBJECT_AREAS_HOME}`
MODEL_HOME=${HOME}/models
COMMON_MODULES_HOME=${SUBJECT_AREAS_HOME}/shared/shared-projects/shared-project/shared-project-modules
#Loads user namespace properties file. User may override namespace properties
#in his home folder in that case that file should be loaded after default name
#space properties file is loaded so that user is given chance to create his own 
#namespace.
#NOTE: This parameter is also used in the functions.sh file 
USER_NAMESPACE_PROPERTIES_FILE='~/.nsrc'

#Load all configurations files in order
. ${HOME}/etc/namespace.properties                                                             
if [ -f "$USER_NAMESPACE_PROPERTIES_FILE" ];                                                             
then
. ${USER_NAMESPACE_PROPERTIES_FILE}
fi
. ${HOME}/etc/default.env.properties                                                                     
. ${SUBJECT_AREA_HOME}/etc/subject-area.env.properties
. ${PROJECT_HOME}/etc/project.env.properties
. ${MODULE_HOME}/etc/module.env.properties
. ${MODULE_HOME}/etc/module.pig.properties

#load all utility functions
. ${HOME}/bin/functions.sh

################################################################################
#                                 Declaration                                  #
################################################################################


################################################################################
#                                  Initialise                                  #
################################################################################










################################################################################
#                                Implementation                                #
################################################################################

function fn_module_setup(){

   hive_table_data_layer_dir="${DATA_LAYER_DIR_INCOMING_SUBJECT_AREA}/${table_artcle_score_incoming}"
  fn_hadoop_delete_directory_if_exists "${hive_table_data_layer_dir}"
  fn_get_current_batch_id

  fn_get_module_log_dir_and_file

  fn_module_create_hive_table_data_layer_directory_structure \
    "${DATA_LAYER_DIR_INCOMING_SUBJECT_AREA}" \
    "${table_artcle_score_incoming}" \
    "${BOOLEAN_TRUE}"

  fn_create_hive_table \
    "${HIVE_DATABASE_NAME_INCOMING}" \
    "${DATA_LAYER_DIR_INCOMING_SUBJECT_AREA}" \
    "${table_artcle_score_incoming}" \
    "${MODULE_HOME}/schema/module.hql"

}


function fn_module_transform(){
  fn_get_current_batch_id

  fn_execute_pig -param MODULE_HOME="${MODULE_HOME}/pig" -param COMMON_MODULES_HOME="${COMMON_MODULES_HOME}" -param JSON_JAR="${JSON_JAR}" -param ELEPHANT_PIG_JAR="${ELEPHANT_PIG_JAR}" -param ELEPHANT_HADOOP_JAR="${ELEPHANT_HADOOP_JAR}" -param HTML_REMOVEL_JAR="${HTML_REMOVEL_JAR}" -param MODEL_HOME="${MODEL_HOME}" -param WORK_DATA="${FEEDLY_DATA_WRK}" -useHCatalog "${MODULE_HOME}/pig/module-transform.pig"
}

fn_main "$@"

################################################################################
#                                     End                                      #
################################################################################
