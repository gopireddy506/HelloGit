package com.hcsc.uuid;


import java.io.IOException;
import java.util.UUID;

import org.apache.pig.EvalFunc;
import org.apache.pig.builtin.Nondeterministic;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.util.UDFContext;
/**
 * Generates a random UUID using java.util.UUID
 */
public class HcscUUID extends EvalFunc<String>
{
    public String exec(Tuple input) throws IOException
    {
    	UDFContext context = UDFContext.getUDFContext();
    	String taskId=context.getJobConf().get("mapred.task.id");
    	String[] map_id=taskId.split("m_");
     	String unique_id=map_id[1]+UUID.randomUUID().toString();

        return unique_id;
    }

   
}