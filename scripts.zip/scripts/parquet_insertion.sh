
script_path="/var/local/scripts/"
common_file="dr_to_pr_segment_tables"
#selected_file="common_insert_input_cdx"
selected_file="$1"

function usage() {
    echo 'Usage: '$0' < inputfile > '
    echo
    exit 1;
}


if [ -f $script_path/$selected_file ] 
then
    echo "File Exist"
    
else
    echo "File doesnot Exist "
    usage
fi

while read table_nm
do
    
    table_flag=`cat $script_path/$common_file | grep -w $table_nm | wc -l`

    if [ $table_flag -ne 1 ];then echo -e "\nTable($table_nm) name not Found in Common File /Duplicate Table name Found" ; exit ; fi

    echo -e "\nTable to be insert : $table_nm"

    hive_table_nm=`cat $script_path/$common_file | grep -w $table_nm | awk -F'|' '{print $1}'`
    hive_db=`cat $script_path/$common_file | grep -w $table_nm | awk -F'|' '{print $2}'`
    impala_table_nm=`cat $script_path/$common_file | grep -w $table_nm | awk -F'|' '{print $3}'`
    impala_db=`cat $script_path/$common_file | grep -w $table_nm | awk -F'|' '{print $4}'`


    impala-shell -i bsenhdslv02 -q" use $hive_db;invalidate metadata ;
                                    insert into table ${impala_db}.${impala_table_nm} select * from ${hive_db}.${hive_table_nm};"



done < $script_path/$selected_file
