#cat /tmp/report.txt | grep "\[\?1034h" | cut -d "1034h" -f2
hdfs_path="/var/local"
 if [[ -n $hdfs_path ]]
 then
 echo "$hdfs_path not empty"
 fi
 if (ssh bouser@141.9.1.36 '[ -d /backup/copy-dims ]')
 then
    echo "exist"
 else
    echo "not"
 fi
