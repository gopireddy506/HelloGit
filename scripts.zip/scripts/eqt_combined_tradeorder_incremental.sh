##
# Production Access Node  
##
STATUS_VAR=""
YEAR="2017"
COPY_STATUS_PATH=/tmp/user_status_log
REMOTE_COPY_STATUS_PATH=/tmp/user_status_log
DR_EQT_LOCAL_PATH=/backup/work/bseorderdata/equity_combined
DR_EQT_HDFS_PATH=/work/eqt_combined_tradeorder/
PR_EQT_LOCAL_PATH=/data2/work/bseorderdata/equity_combined
PR_EQT_HDFS_PATH=/work/eqt_combined_tradeorder/



TABLE_NAME="eqt_combined_tradeorder"
COPY_DATE="$1" 

function usage
{
	echo "$0 <order-date>"
    echo
}
echo "..............................................."
echo "Initiating Copy For : $TABLE_NAME"
echo "Initiating Copy For : $COPY_DATE"
echo "..............................................."
echo

WORKING_DATE=""


LOG_ROOT_PATH="/var/log/dr/"
SCRIPT_EQT_LOG_PATH="$LOG_ROOT_PATH/eqt_tradeorder-daily"

ssh -n bouser@141.9.1.36 rm -rf "$DR_EQT_LOCAL_PATH"/*

rm -rf "$PR_EQT_LOCAL_PATH"/*


if [ "$COPY_DATE" == "" ]
then
	pr_dt=`date +%Y-%m-%d`
	WORKING_DATE=`date -d "$pr_dt -1 days" +%Y-%m-%d`
	Y=`echo $WORKING_DATE | cut -d"-" -f1`
	M=`echo $WORKING_DATE | cut -d"-" -f2`
	D=`echo $WORKING_DATE | cut -d"-" -f3`
	MM=`echo $M | awk '{print $0+0}'`
	DD=`echo $D | awk '{print $0+0}'`
    CURR_DATE=$Y$M$D
else
	WORKING_DATE="$COPY_DATE"
	Y=`echo $WORKING_DATE | cut -d"-" -f1`
	M=`echo $WORKING_DATE | cut -d"-" -f2`
	D=`echo $WORKING_DATE | cut -d"-" -f3`
	MM=`echo $M | awk '{print $0+0}'`
	DD=`echo $D | awk '{print $0+0}'`
    CURR_DATE="$Y$M$D"
fi
echo ".............................."
echo "Working Date Is : $WORKING_DATE"
echo ".............................."
echo
exec 5>&1
exec 6>&2


EQT_TRADEORDER_OUTPUT_LOG="$SCRIPT_EQT_LOG_PATH/order"_"$WORKING_DATE"".out"
EQT_TRADEORDER_ERROR_LOG="$SCRIPT_EQT_LOG_PATH/order-error"$WORKING_DATE".log"

#Copying file from hdfs to local
if [ "$TABLE_NAME" == "eqt_combined_tradeorder" ]
then
	exec 1> "$EQT_TRADEORDER_OUTPUT_LOG"
	exec 2> "$EQT_TRADEORDER_ERROR_LOG"

	echo -e "Copying the order to local system....\n "
    echo
	/usr/bin/hadoop fs -copyToLocal "$PR_EQT_HDFS_PATH"/$CURR_DATE "$PR_EQT_LOCAL_PATH"
	if [ $? -eq 0 ]
	then
		echo "Copying order to the local file system is successfull.....!!!"
        echo
		echo "Creating the status file on production Access Node..."
        echo
		touch "$COPY_STATUS_PATH"/"$TABLE_NAME"_"$WORKING_DATE".PRSuccess
		echo "Copying the file to remote accessnode...."
        echo
		/usr/bin/scp -r "$PR_EQT_LOCAL_PATH"/$CURR_DATE 141.9.1.36:"$DR_EQT_LOCAL_PATH"
		if [ $? -eq 0 ]
		then
			echo "SCP to DR Access Node is successfull.....!!!"
            echo
			echo "Uploading the file on DR Cluster..."
            echo
			ssh -n bouser@141.9.1.36 hadoop fs -Ddfs.block.size=734003200 -copyFromLocal "$DR_EQT_LOCAL_PATH"/$CURR_DATE "$DR_EQT_HDFS_PATH/"
			if [ $? -eq 0 ]
			then
	
				echo "Creating the status file on the DR Access Node..."
                echo
				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$TABLE_NAME"_"$WORKING_DATE".DRSuccess
	
				echo "Deleting the DR Accessnode Local Copy of orderdate=$WORKING_DATE ..."
                echo
              #  ssh -n bouser@141.9.1.36 rm -rf "$DR_EQT_LOCAL_PATH"/$CURR_DATE
                echo "Deleting the PR Accessnode Local Copy of orderdate=$WORKING_DATE ..."
                echo
                rm -rf "$PR_EQT_LOCAL_PATH"/$CURR_DATE
				
                ssh -n bouser@141.9.1.36 "impala-shell -i imp --quiet -q \"use bsedb_impala;alter table eqt_combined_tradeorder add if not exists partition (tradedate='$WORKING_DATE') LOCATION '$DR_EQT_HDFS_PATH/$CURR_DATE';\""

			else
				echo "order Upload to DR Cluster Failed..."
                echo
				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$TABLE_NAME"_"$WORKING_DATE".DRFailed
			fi
		fi
	exec 1>&6 6>&-
	exec 2>&5 5>&-
	fi
	
else 
    echo "Someting went Wrong"
    usage
fi

