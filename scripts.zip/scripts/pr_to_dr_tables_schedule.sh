

# Following code copy data from Production cluster to DR cluster for mentioned tables

sh /home/bouser/check_tables_status.sh -t equity_trade_fact
sh /home/bouser/check_tables_status.sh -t equity_derivatives_trade_fact
sh /home/bouser/check_tables_status.sh -t cdx_trade_fact
sh /home/bouser/check_tables_status.sh -t equity_order_fact
sh /home/bouser/check_tables_status.sh -t equity_derivatives_order_fact
sh /home/bouser/check_tables_status.sh -t equity_cdx_order_fact
sh /var/local/scripts/dr_tables_report.sh
