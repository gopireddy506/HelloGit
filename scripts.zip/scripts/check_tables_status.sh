	#This code will check the status of DR tables and move missing data to DR


	Red='\033[0;31m'          # Red
	Green='\033[0;32m'        # Green
	Yellow='\033[0;33m'       # Yellow
	Color_Off='\033[0m' 	
	

	find_missing_dates()
	{
	table_nm="$1"
	echo "missing dates"
	echo -e "Removing previous files"
	rm -rf ${table_nm}.txt
	rm -rf dr_${table_nm}.txt
	rm -rf diff_${table_nm}.txt
	
	echo -e "Checking $table_nm partitions in PR....\n"
	impala-shell -B -i bsenhdslv01 -q "show partitions bsedb_impala.$table_nm" | awk '{print $1}' > ${table_nm}.txt	
	sed -i '1d' ${table_nm}.txt
	echo -e "Checking $table_nm tables in DR....\n"
			
	ssh -n dr "impala-shell -B -i imp -q \"show partitions bsedb_impala.$table_nm \" " | awk '{print $1}' > dr_${table_nm}.txt
	sed -i '1d' dr_${table_nm}.txt
	
	if [[ -s "${table_nm}.txt" && -s dr_${table_nm}.txt ]];then
		echo	
		echo "Finding difference in PR and DR"	
		diff ${table_nm}.txt dr_${table_nm}.txt > diff_${table_nm}.txt	
	
		cat diff_${table_nm}.txt | grep "<" | awk '{print $2}' > process_dates
		if [ -s "process_dates" ]
		then
			echo "Processing dates"
			returnval=0
		else
			echo "No Processing dates"
			returnval=1
		fi
		
		return "$returnval"
	else
		displayErr "Faillure occured while checking partitions"
		
	fi
	

	}
	
	function displayErr() {
    	echo
    	echo $1;
    	echo
    	exit 1;
	}
function usage() {
    echo 'Usage: '$0' [[-h|--help]|[--table|-t]] [equity_trade_fact|equity_derivatives_trade_fact|cdx_trade_fact|equity_order_fact|equity_derivatives_order_fact|equity_cdx_order_fact]'
    echo
    exit 1;
}

while [ $# -gt 0 ]; do
    case $1 in
        --help | -h)
            usage $0
        ;;
        --table | -t) shift; table=$1; shift; ;;
        *) usage $0; ;;
    esac
done

test -z $table && usage $0


case $table in
    equity_trade_fact)
        # 
        find_missing_dates $table
	returnval=$?
	if [ "$returnval" == 0 ] ; then
		echo
		echo "find : `cat process_dates | wc -l` new partitions"
		echo
    #            read -p "Are you sure to proceed [Y]? " -n 1 -r
     #           echo
      #          if [[ ! $REPLY =~ ^[Yy]$ ]]
       #         then
        #        exit 1
         #       fi
		echo
	 	echo "Processing for : $table "
		echo -e "Moving data from PR to DR \n"
       		
	         rm -rf fail_dates
		while IFS= read -r line
                do
                       sh equity_incremental.sh trade $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
				echo
				echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates
	
        else
           displayErr "$table table is upto date / No data to move"
        fi

        ;;
    equity_derivatives_trade_fact)
	find_missing_dates $table
        returnval=$?
        if [ "$returnval" == 0 ] ; then
                echo
		echo "find : `cat process_dates | wc -l` new partitions"
		echo
	#	read -p "Are you sure to proceed [Y]? " -n 1 -r
	#	echo
	#	if [[ ! $REPLY =~ ^[Yy]$ ]]
	#	then
    #		exit 1
	#	fi
		echo
		echo "Processing for $table "
                echo -e "Moving data from PR to DR \n"
                rm -rf fail_dates
                while IFS= read -r line
                do
                       sh eqd_incremental.sh trade $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
				echo
				echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates

        else
           displayErr "$table table is upto date / No data to move"
        fi

	;;
	cdx_trade_fact)
        find_missing_dates $table
        returnval=$?
        if [ "$returnval" == 0 ] ; then
		echo
                echo "find : `cat process_dates | wc -l` new partitions"
		echo
     #           read -p "Are you sure to proceed [Y]? " -n 1 -r
      #          echo
       #         if [[ ! $REPLY =~ ^[Yy]$ ]]
        #        then
         #       exit 1
          #      fi

		echo
		echo "Processing for $table "
                echo -e "Moving data from PR to DR \n"
                rm -rf fail_dates
                while IFS= read -r line
                do
                       sh cdx_incremental.sh trade $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
				echo
				echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates

        else
           displayErr "$table table is upto date / No data to move"
        fi

	;;
        equity_order_fact)
        find_missing_dates $table
        returnval=$?
        if [ "$returnval" == 0 ] ; then
                echo
                echo "find : `cat process_dates | wc -l` new partitions"
                echo
           #     read -p "Are you sure to proceed [Y]? " -n 1 -r
            #    echo
             #   if [[ ! $REPLY =~ ^[Yy]$ ]]
              #  then
               # exit 1
               # fi

                echo
                echo "Processing for $table "
                echo -e "Moving data from PR to DR \n"
                rm -rf fail_dates
                while IFS= read -r line
                do
                       sh equity_incremental.sh order $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
                                echo
                                echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates

        else
           displayErr "$table table is upto date / No data to move"
        fi

        ;;
        equity_derivatives_order_fact)
        find_missing_dates $table
        returnval=$?
        if [ "$returnval" == 0 ] ; then
                echo
                echo "find : `cat process_dates | wc -l` new partitions"
                echo
               # read -p "Are you sure to proceed [Y]? " -n 1 -r
               # echo
               # if [[ ! $REPLY =~ ^[Yy]$ ]]
               # then
               # exit 1
               # fi

                echo
                echo "Processing for $table "
                echo -e "Moving data from PR to DR \n"
                rm -rf fail_dates
                while IFS= read -r line
                do
                       sh eqd_incremental.sh order $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
                                echo
                                echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates

        else
           displayErr "$table table is upto date / No data to move"
        fi

        ;;
        equity_cdx_order_fact)
        find_missing_dates $table
        returnval=$?
        if [ "$returnval" == 0 ] ; then
                echo
                echo "find : `cat process_dates | wc -l` new partitions"
                echo
               # read -p "Are you sure to proceed [Y]? " -n 1 -r
               # echo
               # if [[ ! $REPLY =~ ^[Yy]$ ]]
               # then
               # exit 1
               # fi

                echo
                echo "Processing for $table "
                echo -e "Moving data from PR to DR \n"
                rm -rf fail_dates
                while IFS= read -r line
                do
                       sh cdx_incremental.sh order $line

                        if [ $? -eq 0 ]
                        then
                                echo "Insertion completed for $line"
                                echo
                                echo "------------------------------"
                        else
                                echo "Insertion failed for $line" >> fail_dates
                        fi


                done < process_dates

        else
           displayErr "$table table is upto date / No data to move"
        fi

        ;;


    *)
        usage $0
        ;;
esac


