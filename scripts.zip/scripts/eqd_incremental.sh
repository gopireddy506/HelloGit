##
# Production Access Node
##
STATUS_VAR=""
YEAR="2015"
COPY_STATUS_PATH=/tmp/status/incremental
REMOTE_COPY_STATUS_PATH=/tmp/status/remote

<<cc
DR_EQD_ORDER_LOCAL_PATH="/backup/work/bseorderdata/eqdrv"
DR_EQD_ORDER_HDFS_PATH="/work/bseorderdata/eqdrv"
PR_EQD_ORDER_LOCAL_PATH="/data2/work/bseorderdata/eqdrv"
PR_EQD_ORDER_HDFS_PATH="/work/bseorderdata/eqdrv"

DR_EQD_TRADE_LOCAL_PATH="/backup/work/bsetradedata/eqdrv"
DR_EQD_TRADE_HDFS_PATH="/work/bsetradedata/eqdrv"
PR_EQD_TRADE_LOCAL_PATH="/data2/work/bsetradedata/eqdrv"
PR_EQD_TRADE_HDFS_PATH="/work/bsetradedata/eqdrv"
cc

DR_EQD_ORDER_LOCAL_PATH="/backup/work/bseorderdata/eqdrv"
DR_EQD_ORDER_HDFS_PATH="/work/bseorderdata/eqdrv"
PR_EQD_ORDER_LOCAL_PATH="/data2/work/bseorderdata/eqdrv"
PR_EQD_ORDER_HDFS_PATH="/work/bseorderdata/eqdrv"

DR_EQD_TRADE_LOCAL_PATH="/backup/work/bsetradedata/eqdrv"
DR_EQD_TRADE_HDFS_PATH="/work/bsetradedata/equitydrv"
PR_EQD_TRADE_LOCAL_PATH="/data2/work/bsetradedata/eqdrv"
PR_EQD_TRADE_HDFS_PATH="/work/bsetradedata/equitydrv"




COPY_DATE=""
COPY_TYPE=""

COPY_TYPE=$1 # trade or order
COPY_DATE=$2 # trade/order copy date


function usage
{
        echo '/var/local/incremental.sh trade/order <trade/order-date>'
        echo
}
echo "........................................"
echo "Initiating Copy For : $COPY_TYPE"
echo "Initiating Copy For : $COPY_DATE"
echo "........................................"
echo

WORKING_DATE=""


LOG_ROOT_PATH="/var/log/dr"
SCRIPT_EQD_ORDER_LOG_PATH="$LOG_ROOT_PATH/eqd_order-daily"
SCRIPT_EQD_TRADE_LOG_PATH="$LOG_ROOT_PATH/eqd_trade-daily"




if [ "$COPY_DATE" == "" ]
then
        pr_dt=`date +%Y-%m-%d`
        WORKING_DATE=`date -d "$pr_dt -1 days" +%Y-%m-%d`
        Y=`echo $WORKING_DATE | cut -d"-" -f1`
        M=`echo $WORKING_DATE | cut -d"-" -f2`
        D=`echo $WORKING_DATE | cut -d"-" -f3`
	MM=`echo $M | awk '{print $0+0}'`
	DD=`echo $D | awk '{print $0+0}'`
else
        WORKING_DATE="$COPY_DATE"
        Y=`echo $WORKING_DATE | cut -d"-" -f1`
	M=`echo $WORKING_DATE | cut -d"-" -f2`
	D=`echo $WORKING_DATE | cut -d"-" -f3`
	MM=`echo $M | awk '{print $0+0}'`
	DD=`echo $D | awk '{print $0+0}'`
fi
echo "................................."
echo "Working Date Is : $WORKING_DATE"
echo "................................."
echo
exec 5>&1
exec 6>&2


EQD_ORDER_OUTPUT_LOG="$SCRIPT_EQD_ORDER_LOG_PATH/eqd_order_${WORKING_DATE}.out"
EQD_ORDER_ERROR_LOG="$SCRIPT_EQD_ORDER_LOG_PATH/eqd_order-error_${WORKING_DATE}.log"
EQD_TRADE_OUTPUT_LOG="$SCRIPT_EQD_TRADE_LOG_PATH/eqd_trade_${WORKING_DATE}.out"
EQD_TRADE_ERROR_LOG="$SCRIPT_EQD_TRADE_LOG_PATH/eqd_trade-error_${WORKING_DATE}.log"



#Copying file from hdfs to local
if [ "$COPY_TYPE" == "order" ]
then
         exec 1> "$EQD_ORDER_OUTPUT_LOG"
	 exec 2> "$EQD_ORDER_ERROR_LOG"
                                   
        echo "Copying the order to local system... "
        echo
     echo "Copying the order to local system... "
     echo
	/usr/bin/hadoop fs -copyToLocal "$PR_EQD_ORDER_HDFS_PATH"/orderdate="$WORKING_DATE" "$PR_EQD_ORDER_LOCAL_PATH"
	if [ $? -eq 0 ]
	then
		echo "Copying equity derivatives order to the local file system is successfull.....!!!"
        echo 
		echo "Creating the status file on production Access Node..."
        echo
		touch "$COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".PRSuccess
		echo "Copying the equity derivatives order file to remote accessnode...."
        echo
		/usr/bin/scp -r "$PR_EQD_ORDER_LOCAL_PATH"/orderdate="$WORKING_DATE" 141.9.1.36:"$DR_EQD_ORDER_LOCAL_PATH"
		if [ $? -eq 0 ]
		then
			echo "SCP to DR Access Node is successfull....!!!"
            echo
			echo "Uploading the file on DR Cluster..."
            echo
			ssh -n bouser@141.9.1.36 hadoop fs -Ddfs.block.size=262144000 -copyFromLocal "$DR_EQD_ORDER_LOCAL_PATH"/orderdate="$WORKING_DATE" "$DR_EQD_ORDER_HDFS_PATH/$Y/"
			if [ $? -eq 0 ]
			then 
				echo "Creating the status file on the DR Access Node..."
                echo
				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".DRSuccess
	
				echo "Deleting the DR Accessnode Local Copy of equity derivatives orderdate=$WORKING_DATE ..."
                echo
                                ssh -n bouser@141.9.1.36 rm -rf "$DR_EQD_ORDER_LOCAL_PATH"/orderdate="$WORKING_DATE"
                                echo "Deleting the PR Accessnode Local Copy of equity derivatives orderdate=$WORKING_DATE ..."
                                echo
                                rm -rf "$PR_EQD_ORDER_LOCAL_PATH"/orderdate="$WORKING_DATE"
				# Creating partition
                                ssh -n bouser@141.9.1.36 "impala-shell -i imp --quiet -q \"use bsedb_impala;alter table equity_derivatives_order_fact add if not exists partition (orderdate='$WORKING_DATE',year=$Y,month=$M,day=$D) LOCATION '$DR_EQD_ORDER_HDFS_PATH/$Y/orderdate=$WORKING_DATE/year=$Y/month=$MM/day=$DD';\""
				
			else
				echo "equity derivatives order Upload to DR Cluster Failed..."
                echo

				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".DRFailed
			fi
		fi
        exec 1>&6 6>&-
        exec 2>&5 5>&-
        fi

elif [[ "$COPY_TYPE" == "trade" ]]
then
     #   exec 5>&1
      #  exec 6>&2

      #  exec 1> "$EQD_TRADE_OUTPUT_LOG"
      #  exec 2> "$EQD_TRADE_ERROR_LOG"

       echo "Copying the equity derivatives trade to local system...."
       echo
	/usr/bin/hadoop fs -copyToLocal "$PR_EQD_TRADE_HDFS_PATH/"tradedate="$WORKING_DATE" "$PR_EQD_TRADE_LOCAL_PATH"
	if [[ $? -eq 0 ]]
	then
		echo "Copying the equity derivatives trade file to local system is successfull.....!!!"
        echo
		echo "Creating the status file on the production access node..."
        echo
		touch "$COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".PRSuccess
		echo "Copying the equity derivatives trade file to remote system..."
        echo
		/usr/bin/scp -r "$PR_EQD_TRADE_LOCAL_PATH/"tradedate="$WORKING_DATE" bouser@141.9.1.36:"$DR_EQD_TRADE_LOCAL_PATH"
		if [[ $? -eq 0 ]]
		then
			echo "SCP to DR access node is successfull....!!!"
            echo
			echo "Uploading equity derivatives trade on DR Cluster..."
            echo
			ssh -n bouser@141.9.1.36 hadoop fs -copyFromLocal "$DR_EQD_TRADE_LOCAL_PATH/"tradedate="$WORKING_DATE" "$DR_EQD_TRADE_HDFS_PATH"/"$Y"
			if [[ $? -eq 0 ]]
			then
				echo "Creating the status file for equity derivatives trade on the DR Access Node..."
                echo
				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".DRSuccess
				
				# Cleaning the local files
				echo "Deleting the DR Accessnode Local Copy of equity derivatives tradedate=$WORKING_DATE ..."
                echo
				ssh -n bouser@141.9.1.36 rm -rf "$DR_EQD_TRADE_LOCAL_PATH"/tradedate="$WORKING_DATE"
				echo "Deleting the PR Accessnode Local Copy of equity derivatives tradedate=$WORKING_DATE ..."
                echo
				rm -rf "$PR_EQD_TRADE_LOCAL_PATH"/tradedate="$WORKING_DATE"
				# Creating partition 
                                ssh -n bouser@141.9.1.36 "impala-shell -i imp --quiet -q \"use bsedb_impala;alter table equity_derivatives_trade_fact add if not exists partition (tradedate='$WORKING_DATE',year=$Y,month=$M,day=$D) LOCATION '$DR_EQD_TRADE_HDFS_PATH/$Y/tradedate=$WORKING_DATE/year=$Y/month=$MM/day=$DD';\"" 
                                ###
			else
				echo "equity derivatives trade Upload to DR Cluster Failed..."
                echo
				ssh -n bouser@141.9.1.36 touch "$REMOTE_COPY_STATUS_PATH"/"$COPY_TYPE"/"$WORKING_DATE"_"$COPY_TYPE".DRFailed
			fi	
		fi
      #  exec 1>&6 6>&-
      #  exec 2>&5 5>&-

        fi
else
        echo '/var/local/incremental trade/order <trade/order-date>'
        echo
fi

