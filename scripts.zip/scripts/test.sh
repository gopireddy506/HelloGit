 while read line
         do
        TABLE_ARRAY[$i]=$liT=`echo ${TABLE_ARRAY[$i]} | cut -d"
                                         " -f1`
                                                         D=`echo
                                                         ${TABLE_ARRAY[$i]} |
                                                         cut -d"  " -f2`
                                                                         ((i++))
                                                                                 done
                                                                                 <
                                                                                 "$CONF_FILE_PATH"/"$CONF_FILE_NAME"

