ARG="$1"
if [ ${#ARG} -eq 0 ]
then
current_date=`date +%Y-%m-%d`
else
current_date="$ARG"
fi


impala-shell -i bsenhdslv01 -B -q "use bsedb_impala; invalidate metadata;
select \`date\` from date_dim where \`date\` <= '$current_date' and trim(UPPER(working_day_flag)) = 'Y' order by \`date\` desc limit 5;" -o /tmp/last_five_days

sed -i '/^$/d' /tmp/last_five_days
if [ `cat /tmp/last_five_days | wc -l` -eq 5 ]
then
	SD=`sed -n "1p" /tmp/last_five_days`
	ED=`sed -n "5p" /tmp/last_five_days`
	echo "Considering Dates $ED to $SD"
	
	ssh -n dr "impala-shell -i imp --output_delimiter=\",\" -q \"use bsedb_impala; invalidate metadata;
                select trade_date AS Eqt_Trade,count(*) from equity_trade_fact where tradedate >= '$ED' group by trade_date order by trade_date limit 10;
		select trade_date AS Fno_Trade,count(*) from equity_derivatives_trade_fact where tradedate >= '$ED' group by trade_date order by trade_date limit 10;
                select trade_date AS Cdx_Trade,count(*) from cdx_trade_fact where tradedate >= '$ED' group by trade_date order by trade_date limit 10;
                select order_date AS Eqt_Order,count(*) from equity_order_fact where orderdate >= '$ED' group by order_date order by order_date limit 10;
                select order_date AS Fno_Order,count(*) from equity_derivatives_order_fact where orderdate >= '$ED' group by order_date order by order_date limit 10;
                select order_date AS Cdx_Order,count(*) from equity_cdx_order_fact where orderdate >= '$ED' group by order_date order by order_date limit 10;\" " | 
	 mail -r gopireddy.guthikonda@bseindia.com -s "DR COPY STATUS : EQT FNO CDX Trade Counts on $current_date" \
     dulal.mali@bseindia.com,gopireddy.guthikonda@bseindia.com,k.mohanan@bseindia.com,bhalchandra.pawar@bseindia.com,Ravi.Shekhar@bseindia.com,sanjay.gupta@bseindia.com,saurabh.gaikwad@bseindia.com
#	echo "REDDY" | mail -s "DailyJob" gopireddy.guthikonda@bseindia.com
else
	echo "Someting went wrong while taking dates"
fi
